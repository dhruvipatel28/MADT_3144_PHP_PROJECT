
<?php
    
    // session_start();


// //session_start();
// if(isset($_SESSION)){
//   echo "Session Set";
// }
// $_SESSION['test 1'] = "Success";

//      echo "<pre> Session : ";
//      print_r($_SESSION);
//      echo "</pre>";

     

//      if(isset($_SESSION['LoginFlag'])) {
//       echo "Your session is running " . $_SESSION['LoginFlag'];
//     }
    


//     echo "This Is : " . $_SESSION['LoginFlag'];

//     // if($_SESSION["LoginFlag"] == false || !isset($_SESSION['LoginFlag'])){

//     //   echo "<script type='text/javascript'> location.href = 'login.php'; </script>";

//     // }

    
 
  


 // 1 - Database information
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $dbname = "my_db";

 // 2 - Connect to the database and handle any connection errors
 $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
 if (mysqli_connect_errno())
 {
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
   exit();
 }


 if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["add"])) {

    // echo "<pre>";
    // print_r($_POST);
    // echo "</pre>";


    $qury_insert = "INSERT INTO bus_schedule (bus_time,mississauga,brampton,to_college,from_college,on_saturday) VALUES('" . $_POST['time'] . "',";

    if($_POST['mississauga'] == true){

      $qury_insert .= "'1',";

    }else{

      $qury_insert .= "'0',";

    }

    if($_POST['brampton'] == true){

      $qury_insert .= "'1',";

    }else{

      $qury_insert .= "'0',";

    }
    if($_POST['to_lambton'] == true){

      $qury_insert .= "'1',";

    }else{

      $qury_insert .= "'0',";

    }
    
    
    if($_POST['from_lambton'] == true){

      $qury_insert .= "'1',";

    }else{

      $qury_insert .= "'0',";

    }
    
   
    if($_POST['on_saturday'] == true){

      $qury_insert .= "'1'";

    }else{

      $qury_insert .= "'0'";

    }
    
    $qury_insert .= ")";
    // echo $qury_insert;
    $results_insert = mysqli_query($connection, $qury_insert);

 }


// Add Code Over


// Update Code Start


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["update"])) {

  // echo "<pre>";
  // print_r($_POST);
  // echo "</pre>";


  $qury_update = "UPDATE bus_schedule SET bus_time = '" . $_POST['time'] . "',";

  if($_POST['mississauga'] == true){

    $qury_update .= "mississauga = '1',";

  }else{

    $qury_update .= "mississauga = '0',";

  }

  if($_POST['brampton'] == true){

    $qury_update .= "brampton = '1',";

  }else{

    $qury_update .= "brampton = '0',";

  }
  if($_POST['to_lambton'] == true){

    $qury_update .= "to_college = '1',";

  }else{

    $qury_update .= "to_college = '0',";

  }
  
  
  if($_POST['from_lambton'] == true){

    $qury_update .= "from_college = '1',";

  }else{

    $qury_update .= "from_college = '0',";

  }
  
 
  if($_POST['on_saturday'] == true){

    $qury_update .= "on_saturday = '1'";

  }else{

    $qury_update .= "on_saturday = '0'";

  }
  
  $qury_update .= "where id = '" . $_POST['id'] . "'";
  // echo $qury_update;
 $results_update = mysqli_query($connection, $qury_update);

}

// Update Code Over 



// Delete Code Start


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["delete"])) {

  // echo "<pre>";
  // print_r($_POST);
  // echo "</pre>";


  $qury_update = "DELETE FROM bus_schedule WHERE id = '" . $_POST['id'] . "'";

  
  // echo $qury_update;
 $results_delete = mysqli_query($connection, $qury_update);

}

// Delete Code Over 

    $query = "SELECT * FROM bus_schedule  ORDER BY bus_time ASC";

    $results = mysqli_query($connection, $query);

?>

<!DOCTYPE html>
<html>
  <head>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>

    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>


    <style type="text/css">
   
      .heading{

        font-size : 47px;
        font-weight : 700;

      }
      .inline-left{

        display:inline;
        float:left;

      }
      .float-right{

        float : right;

      }
      .lever-title{

        font-size : 18px;

      }
        
      @media only screen and (min-width : 601px) and (max-width : 1260px) {
.toast {
width: 100%;
border-radius: 0;} }

@media only screen and (min-width : 1261px) {
.toast {
width: 100%;
border-radius: 0; } }

@media only screen and (min-width : 601px) and (max-width : 1260px) {
#toast-container {
min-width: 100%;
bottom: 0%;
top: 90%;
right: 0%;
left: 0%;} }

@media only screen and (min-width : 1261px) {
#toast-container {
min-width: 100%;
bottom: 0%;
top: 90%;
right: 0%;
left: 0%; } }

    </style>


  </head>

  <body class="white">
    <!--Import jQuery before materialize.js-->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="materialize/js/materialize.min.js"></script>


    <nav class="blue-grey lighten-5">
    <div class="nav-wrapper">
      <a href="#" class="brand-logo "></a><img src="Logo-hover.jpg" alt="" style = "width:200px; margin-left:100px">
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <!-- <li><a href="sass.html" class="light-blue darken-4">Add</a></li> -->
        <!-- <li><a href="badges.html" class="light-blue darken-4">Timings</a></li>
        <li><a href="collapsible.html" class="light-blue darken-4">Buses</a></li> -->
        <li><a href="login.php" class="light-blue darken-4">Logout</a></li>
      </ul>
    </div>
  </nav>

    

     <div class="container white" style = "margin-top:100px" id="container">
      <div class="row valign-wrapper">
        <div class="col l9">
           <p class="heading ">Shuttle Bus Schedule</p>
        </div>
        <div class="col l3">
          <a class="waves-effect waves-light btn modal-trigger light-green " href="#modal1"><i class="material-icons left">add_box</i>Add</a>
        </div>
     </div>
     <div class = "col l12"> 
          <p><span style=" font-size : 18px; font-weight : 700;"> Note : </span><span style=" text-decoration:underline;">Bus Service Runs from Monday to Saturday</span></p> 
        </div>
     
     <div class="row">
     <div class="col l12">
     <table class="responsive-table highlight">
        <thead>
          <tr>
              <th>Time</th>
              <th>Pick-Up</th>
              <th>Drop</th>
              <th>On Saturday</th>
              <th>Edit</th>
          </tr>
        </thead>

        <tbody>

          <?php
          
            while ($bus = mysqli_fetch_assoc($results)) { 

              
              $pickup = "";


              if($bus['to_college'] == true){
                
                if($bus['mississauga'] == true){

                  $pickup .= "Mississauga";

                }
                if($bus['brampton'] == true && $bus['mississauga'] == true){

                  $pickup .= " - ";

                }
                if($bus['brampton'] == true){

                  $pickup .= "Brampton";

                }

                $destination = "Lambton College";

              }else if($bus['from_college'] == true){
                
                $pickup = "Lambton College";
                $destination = "";

                if($bus['mississauga'] == true){

                  $destination .= "Mississauga";

                }
                if($bus['brampton'] == true && $bus['mississauga'] == true){

                  $destination .= " - ";

                }
                 if($bus['brampton'] == true){

                  $destination .= "Brampton";

                }

              }
              

              if($bus['on_saturday'] == true){
                
                $saturday = "";
                $sat_flag = "Available";
                 
              }else{

                $saturday = "Not Available";
                $sat_flag = "Not Available";

              }

          ?>


          <tr>
            <td><?php echo $bus['bus_time'];?></td>
            <td><?php echo $pickup; ?></td>
            <td><?php echo $destination; ?></td>
            <td><?php echo $saturday; ?></td>
            <td> <a class="waves-effect waves-light btn modal-trigger " href="#modal2" data-toggle="modal" 
              data-id = "<?php echo $bus['id'];?>" 
              data-time = "<?php echo $bus['bus_time'];?>"
              data-mississauga = "<?php echo $bus['mississauga'];?>"
              data-brampton = "<?php echo $bus['brampton'];?>"
              data-tocollege = "<?php echo $bus['to_college'];?>"
              data-fromcollege = "<?php echo $bus['from_college'];?>"
              data-onsaturday = "<?php echo $bus['on_saturday'];?>"
              id = "edit_bus" ><i class="material-icons left">edit</i>Edit</a>

             <a class="waves-effect waves-light btn modal-trigger   deep-orange darken-3" href="#modal3"
             
              data-toggle="modal" 
              data-id = "<?php echo $bus['id'];?>" 
              data-time = "<?php echo $bus['bus_time'];?>"
              data-pickup = "<?php echo $pickup;?>"
              data-destination = "<?php echo $destination;?>"
              data-saturday = "<?php echo $sat_flag;?>"
             
              id="delete_bus"><i class="material-icons left">delete_sweep</i>Delete</a></td>
          </tr>
            <?php }?>
         
        </tbody>
      </table>
            
     </div>
     </div>

    </div>
        


<!-- Modal 1 Structure -->
<div id="modal1" class="modal">
  <div class="modal-content">
    <h4>Add Bus</h4>
    <form action="" method="POST" class="col s12">
              
                    <div class="row"></div>

                   

              <div class="row">
                <div class="col l2"></div>
                <div class="input-field col l8">
                  <input type="text" class="timepicker" name="time" >
                  <label for="time">Time</label>
                </div>
                <div class="col l2"></div>
              </div>

              <div class="row">
              <div class="col l1"></div>
                <div class="col l2">
                  <label for="lever" class="lever-title">From Lambton</label>
                  <!-- Switch -->
                  <div class="switch">
                    <label>
                    No
                    <input type="checkbox" name = "from_lambton" >
                    <span class="lever"></span>
                    Yes
                    </label>
                  </div>
                </div>
                <div class="col l2">
                  <label for="lever" class="lever-title">To Lambton</label>
                  <!-- Switch -->
                  <div class="switch">
                    <label>
                    No
                    <input type="checkbox" name = "to_lambton" >
                    <span class="lever"></span>
                    Yes
                    </label>
                  </div>
                </div>
                
                <div class="col l2">
                  <label for="lever" class="lever-title">Mississauga</label>
                  <!-- Switch -->
                  <div class="switch">
                    <label>
                    No
                    <input type="checkbox" name = "mississauga" >
                    <span class="lever"></span>
                    Yes
                    </label>
                  </div>
                </div>
                
                <div class="col l2">
                  <label for="lever" class="lever-title">Brampton</label>
                  <!-- Switch -->
                  <div class="switch">
                    <label>
                    No
                    <input type="checkbox" name = "brampton" >
                    <span class="lever"></span>
                    Yes
                    </label>
                  </div>
                </div>
                
                <div class="col l2">
                  <label for="lever" class="lever-title">On Saturday</label>
                  <!-- Switch -->
                  <div class="switch">
                    <label>
                      No
                      <input type="checkbox" name = "on_saturday" >
                      <span class="lever"></span>
                      Yes
                    </label>
                  </div>
                </div>
                <div class="col l1"></div>
              </div>

              
              <div class="row">
                    <div class="col l4"></div>
                <div class="input-field col l4">
                        <button type="submit" class="waves-effect waves-light btn inline-left" name = "add" id="addupdate">Add</button>
                        <button type="button" class="waves-effect waves-light btn modal-close float-right brown darken-3">Close</button>
                </div>
                <div class="col l4"></div>
              </div>

              <div class="row"></div>

            </form>

  </div>
  <div class="modal-footer">
    

  </div>
</div>
<!-- //Modal 1 Structure -->



<!-- Modal 2 Structure -->
<div id="modal2" class="modal">
  <div class="modal-content">
    <h4>Update Bus</h4>
    <form action="" method="POST" class="col s12">
              
          <div class="row"></div>

                   

              <div class="row">
                <div class="col l2"></div>
                <div class="input-field col l8">
                  <input type="hidden" name = "id" id = "id">
                  <input type="text" class="timepicker" name="time" id="time">
                  <label for="time">Time</label>
                </div>
                <div class="col l2"></div>
              </div>

              <div class="row">
              <div class="col l1"></div>
                <div class="col l2">
                  <label for="lever" class="lever-title">From Lambton</label>
                  <!-- Switch -->
                  <div class="switch">
                    <label>
                    No
                    <input type="checkbox" name = "from_lambton" id="fromLambton">
                    <span class="lever"></span>
                    Yes
                    </label>
                  </div>
                </div>
                <div class="col l2">
                  <label for="lever" class="lever-title">To Lambton</label>
                  <!-- Switch -->
                  <div class="switch">
                    <label>
                    No
                    <input type="checkbox" name = "to_lambton" id = "tolambton">
                    <span class="lever"></span>
                    Yes
                    </label>
                  </div>
                </div>
                
                <div class="col l2">
                  <label for="lever" class="lever-title">Mississauga</label>
                  <!-- Switch -->
                  <div class="switch">
                    <label>
                    No
                    <input type="checkbox" name = "mississauga" id="mississauga">
                    <span class="lever"></span>
                    Yes
                    </label>
                  </div>
                </div>
                
                <div class="col l2">
                  <label for="lever" class="lever-title">Brampton</label>
                  <!-- Switch -->
                  <div class="switch">
                    <label>
                    No
                    <input type="checkbox" name = "brampton" id="brampton">
                    <span class="lever"></span>
                    Yes
                    </label>
                  </div>
                </div>
                
                <div class="col l2">
                  <label for="lever" class="lever-title">On Saturday</label>
                  <!-- Switch -->
                  <div class="switch">
                    <label>
                      No
                      <input type="checkbox" name = "on_saturday" id="onsaturday">
                      <span class="lever"></span>
                      Yes
                    </label>
                  </div>
                </div>
                <div class="col l1"></div>
              </div>

              
              <div class="row">
                    <div class="col l4"></div>
                <div class="input-field col l4">
                        <button type="submit" class="waves-effect waves-light btn inline-left" name = "update" id="addupdate">Update</button>
                        <button type="button" class="waves-effect waves-light btn modal-close float-right brown darken-3">Close</button>
                </div>
                <div class="col l4"></div>
              </div>

              <div class="row"></div>

            </form>

  </div>
  <div class="modal-footer">
    

  </div>
</div>
<!-- //Modal 2 Structure -->


<!-- Modal 3 Structure -->
<div id="modal3" class="modal">
  <div class="modal-content">
    <h4 style = "font-weight : 700;">Are You Sure You Want To Delete It ?</h4>
    <form action="" method="POST" class="col s12">
              <input type = "hidden" name="id" id = "id">
      <div class="row"></div>
        <div class="row">

        <div class = "row">
        <a style = "font-weight : 700; font-size : 33px;">Time : </a>
          <a style = "font-size : 33px;" id = "time"></a>

      </div>
      
      
      <div class = "row">
      
      <a style = "font-weight : 700; font-size : 23px;">Pickup : </a>
          <a style = "font-size : 23px;" id = "pickup"></a>
          
      
      </div>
      <div class = "row"></div>

      <a style = "font-weight : 700; font-size : 23px;">Destination : </a>
          <a style = "font-size : 23px;" id = "destination"></a>
          

      </div>
      <div class = "row"></div>

      <a style = "font-weight : 700; font-size : 23px;">Saturday : </a>
          <a style = "font-size : 23px;" id = "saturday"></a>

          

      </div>

      <div class="row">
        <div class="col l4"></div>
        <div class="input-field col l4">
          <button type="submit" class="waves-effect waves-light btn inline-left deep-orange darken-3" name = "delete" id="addupdate">Delete</button>
          <button type="button" class="waves-effect waves-light btn modal-close float-right light-green" id = "del_close">Close</button>
        </div>
        <div class="col l4"></div>
    </div>
  <div class="row"></div>

          </div>
    </form>

  </div>
  <div class="modal-footer">
    

  </div>
</div>
<!-- //Modal 3 Structure -->
    
<script>

$(document).ready(function(){

  // the "href" attribute of the modal trigger must specify the modal ID that wants to be triggered
  $('.modal').modal();
});

$(document).on("click", "#edit_bus", function () {

  

// alert ("ok");
var bus_id = $(this).data('id');
var bus_time = $(this).data('time');
var bus_mississauga = $(this).data('mississauga');
var bus_brampton = $(this).data('brampton');
var bus_tocollege = $(this).data('tocollege');
var bus_fromcollege = $(this).data('fromcollege');
var bus_onsaturday = $(this).data('onsaturday');

// alert ("Id : " + bus_id + "Time : " + bus_time);


// var product_name = $(this).data('name');
// var product_price = $(this).data('price');
// var product_image = $(this).data('image');
// console.log('proimage---' + product_image);

$(".modal-content #time").val(bus_time);
$(".modal-content #id").val(bus_id);
// $(".modal-content #fromLambton").checked = true;

if(bus_fromcollege == true){

  $("#fromLambton").prop("checked", true);

}else{

  $("#fromLambton").prop("checked", false);

}
if(bus_tocollege == true){

$("#tolambton").prop("checked", true);

}else{

$("#tolambton").prop("checked", false);

}
if(bus_mississauga == true){

$("#mississauga").prop("checked", true);

}else{

$("#mississauga").prop("checked", false);

}
if(bus_brampton == true){

$("#brampton").prop("checked", true);

}else{

$("#brampton").prop("checked", false);

}
if(bus_onsaturday == true){

$("#onsaturday").prop("checked", true);

}else{

$("#onsaturday").prop("checked", false);

}


// $('#modal2').modal('open');

// $(".modal-content #tolambton").val(bus_time);
// $(".modal-content #mississauga").val(bus_time);
// $(".modal-content #brampton").val(bus_time);
// $(".modal-content #onsaturday").val(bus_time);
// $(".modal-body #product_price").val(product_price);
// $(".modal-body #pro_name").val(product_name);
// $(".modal-body #product_image").val(product_image);
// $(".modal-body #product_name").html('Product : ' + product_name);
// // As pointed out in comments, 
// // it is superfluous to have to manually call the modal.
// // $('#addBookDialog').modal('show');
});

$(document).on("click", "#delete_bus", function () {

  

// alert ("ok");
var bus_id = $(this).data('id');
var bus_time = $(this).data('time');
var bus_pickup = $(this).data('pickup');
var bus_destination = $(this).data('destination');
var bus_saturday = $(this).data('saturday');


//  alert ("Id : " + bus_id + "Time : " + bus_time);


// var product_name = $(this).data('name');
// var product_price = $(this).data('price');
// var product_image = $(this).data('image');
// console.log('proimage---' + product_image);

$(".modal-content #time").append(bus_time);
$(".modal-content #id").val(bus_id);
$(".modal-content #pickup").append(bus_pickup);
$(".modal-content #destination").append(bus_destination);
$(".modal-content #saturday").append(bus_saturday);



// $('#modal2').modal('open');

// $(".modal-content #tolambton").val(bus_time);
// $(".modal-content #mississauga").val(bus_time);
// $(".modal-content #brampton").val(bus_time);
// $(".modal-content #onsaturday").val(bus_time);
// $(".modal-body #product_price").val(product_price);
// $(".modal-body #pro_name").val(product_name);
// $(".modal-body #product_image").val(product_image);
// $(".modal-body #product_name").html('Product : ' + product_name);
// // As pointed out in comments, 
// // it is superfluous to have to manually call the modal.
// // $('#addBookDialog').modal('show');
});

$(document).on("click", "#del_close", function () {

  

$(".modal-content #time").empty();
$(".modal-content #id").empty();
$(".modal-content #pickup").empty();
$(".modal-content #destination").empty();
$(".modal-content #saturday").empty();


});


        $('.timepicker').pickatime({
    default: 'now', // Set default time: 'now', '1:30AM', '16:30'
    fromnow: 0,       // set default time to * milliseconds from now (using with default = 'now')
    twelvehour: false, // Use AM/PM or 24-hour format
    donetext: 'OK', // text for done-button
    cleartext: 'Clear', // text for clear-button
    canceltext: 'Cancel', // Text for cancel-button
    autoclose: false, // automatic close timepicker
    ampmclickable: true, // make AM PM clickable
    aftershow: function(){} //Function for after opening timepicker
  });
</script>


<?php


if($_SERVER["REQUEST_METHOD"] == "POST"){
// echo "<br>before Result<br>";
if($results_insert == true){

    // echo "Testedd Result";
    $message = "Bus Added Successfully";
        // echo "<script> Materialize.toast('Bus Added Successfully', 4000); </script>";

}
elseif ($results_update == true){

  $message = "Bus Updated Successfully";

    // echo "<script> Materialize.toast('Error in Database', 4000); </script>";

}elseif($results_delete == true){

    $message = "Bus Deleted Successfully";

}else{

    $message = "Error In Database";
}

echo "<script> Materialize.toast('" . $message . "', 4000); </script>";

}

?>


  </body>
</html>