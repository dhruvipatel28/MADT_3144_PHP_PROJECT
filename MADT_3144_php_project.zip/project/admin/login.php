
<!-- 
<?php

session_start();

$_SESSION['Noname'] = "NoName";

echo "<br>PHP Session : ";

echo PHP_SESSION_ACTIVE;
echo "<br>PHP Session dissabled : ";

echo PHP_SESSION_DISABLED;
echo "<br>PHP Session none: ";

echo PHP_SESSION_NONE;

?> -->


<!DOCTYPE html>
<html>
  <head>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>

    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>


    <style type="text/css">
   
        .main_div{
    
            width:800px; 
            border-radius: 7px;
            padding: 10px;
    
        }
        .my-wrapper{

            height : 976px;

        }
        body{

            height: 100%;
            margin: 0;

        }

    
       </style>


  </head>

  <body>
    <!--Import jQuery before materialize.js-->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   <script type="text/javascript" src="materialize/js/materialize.min.js"></script>



    <!-- <div class="row"></div><div class="row"></div><div class="row"></div>
    <div class="row"></div><div class="row"></div><div class="row"></div>
    <div class="row"></div><div class="row"></div><div class="row"></div>
    <div class="row"></div><div class="row"></div><div class="row"></div>
    <div class="row"></div> -->
 

    <div class="my-wrapper valign-wrapper">

     <div class="row main_div z-depth-5">
            <form action="" method="POST" class="col s12">
              
                    <div class="row"></div>

                    <div class="row">

                        <div class="col l4"></div>
                        <div class="col l4 center-align">
                            <h1>Login</h1>
                        </div>
                        <div class="col l4"></div>

                    </div>  

              <div class="row">
                    <div class="col l2"></div>
                <div class="input-field col l8">
                  <input id="email" type="email" class="validate" name="email">
                  <label for="email">Email</label>
                </div>
                <div class="col l2"></div>
              </div>

              <div class="row">
                    <div class="col l2"></div>
                <div class="input-field col l8">
                  <input id="password" type="password" class="validate" name="password">
                  <label for="password">Password</label>
                </div>
                <div class="col l2"></div>
              </div>
              
              <div class="row">
                    <div class="col l5"></div>
                <div class="input-field col l2">
                        <button type="submit" class="waves-effect waves-light btn">Login</button>
                </div>
                <div class="col l5"></div>
              </div>

              <div class="row"></div>

            </form>
          </div>
        </div>
        



  </body>
</html>



<?php

    if($_SERVER["REQUEST_METHOD"] == "POST"){

    



 // 1 - Database information
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $dbname = "my_db";

 // 2 - Connect to the database and handle any connection errors
 $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
 if (mysqli_connect_errno())
 {
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
   exit();
 }


    echo "Test ok !";
    print_r($_POST);

    $query_select_pass = "SELECT * FROM users WHERE email = '" . $_POST['email'] . "' AND password = '" . $_POST['password'] . "'";

    echo "Query : " . $query_select_pass;

    $result = mysqli_query($connection, $query_select_pass);

    echo "<pre>";
    print_r($result);
    echo "</pre>";
    

    echo "result Here";

    if($result == true){echo "Test Database Run";}else {echo "Not Run";}

    $name = mysqli_fetch_assoc($result);
    echo "<pre>";
    print_r($name);
    echo "</pre>";

    echo "-------------------------------------------------- Num : " . $result->num_rows . "name : " . $name;

    if($result->num_rows > 0){
        

        

         echo "<script type='text/javascript'> location.href = 'adminHome.php'; </script>";


    //  echo "<pre>";
    //  print_r($_SESSION);
    //  echo "</pre>";

    }

    if($_SERVER["REQUEST_METHOD"] == "POST"){    
        if($result->num_rows < 1){

            echo "<script> Materialize.toast('Login Fail !', 4000) // 4000 is the duration of the toast </script>";

        }
        else 
        {
            echo "<script> Materialize.toast('Login Successfully !', 4000) // 4000 is the duration of the toast </script>";
        }
    }

}

?>

