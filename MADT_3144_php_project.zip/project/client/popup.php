
<!DOCTYPE html>
<html>
 <head>
   <!--Import Google Icon Font-->
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
   <!--Import materialize.css-->
   <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>

   <!--Let browser know website is optimized for mobile-->
   <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
   <style type="text/css">
 
       .main_div{
   
           width:800px;
           border-radius: 7px;
           padding: 10px;
   
       }
       .my-wrapper{

           height : 976px;

       }
       body{

           height: 100%;
           margin: 0;

       }

   
      </style>


 </head>

 <body>
   <!--Import jQuery before materialize.js-->
   <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="materialize/js/materialize.min.js"></script>


   <div class="my-wrapper valign-wrapper">

    <div class="row main_div z-depth-5">
         
          <?php if(isset($_POST['name'])){


           echo "<img src='barcode.php?" . $_POST['name'] . "'>";

          }else{?>
         
         
           <form action="" method="POST" class="col s12">
             
                   <div class="row"></div>

                   <div class="row">

                       <div class="col l4"></div>
                       <div class="col l4 center-align">
                           <h5>Book Your Ticket</h5>
						   <label> Enter Your Name and Student Number like : C0xxxxxYOURNAME </label>
                       </div>
                       <div class="col l4"></div>

                   </div>  

             <div class="row">
                   <div class="col l2"></div>
               <div class="input-field col l8">
                 <input id="name" type="text" class="validate" name="name">
                 <label for="email">Enter Your Name</label>
               </div>
               <div class="col l2"></div>
             </div>

             
             <div class="row">
                   <div class="col l5"></div>
               <div class="input-field col l2">
                       <button type="submit" class="waves-effect waves-light btn">Book</button>
               </div>
               <div class="col l5"></div>
             </div>

             <div class="row"></div>

           </form>
          <?php }?>
         </div>
       </div>
       



 </body>
</html>



<?php

 
?>