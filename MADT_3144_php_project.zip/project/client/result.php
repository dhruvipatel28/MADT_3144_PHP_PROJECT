<!--
1->  Set logo on top -> onclick open lambton website.
2->  Seaprate the header and footer files.
3->  Set Dynamic Locations.
4->  Saturday Filteration.
5->  Buy Ticket on click of ticket icon.
6->  Add 2 coulmn to table -> sets & booked sets -> total seats are 45 -> some fixed number of sudent who has pass.
7->  (Table)-> ticket -> bus schedule_id -> time -> student number
          -> barcode text( to check ticket ) -> ticket expire date:today.

8->  Ticket price -> 6am to 4pm & after->$5.
                  -> else $3.
9->  Table -> Bus pass -> student number -> Phone number -> expire date : 31-Aug/30-Apr/31_dec (drop down).
10-> Bus pass expire at 3 date -> 30 april/ 31 august/ 31 december.
11->


-->
<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

    </head>
    <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "my_db";
            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);
            // Check connection

            $action;
            $location;
            $sql;
            $first_bus;
            $next_lbl = "Next Bus ";

            if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['des']))
            {
                $action = $_GET['des'];
                $location = $_GET['loc'];
                $sat = " on_saturday=true ";

                // ------------ Make Query -------------
                if($action == 'to')
                {
                    $sql =  "select * from bus_schedule where from_college=true AND ";
                    $next_lbl = $next_lbl."to ". ucfirst($location) . " : ";
                }
                if($action == 'from')
                {
                    $sql = "select * from bus_schedule where to_college=true AND ";
//                    . $location . "=true ORDER BY bus_time ASC ";
                    //echo "$sql <br><br>";
                    $next_lbl = $next_lbl."for College :";
                }
                // Filteration for sql.
                if (date("D") == "Sat")
                {
                    $sql = $sql . $sat . " AND " . $location . "=true ORDER BY bus_time ASC ";
                }
                else
                {
                    $sql = $sql . $location . "=true ORDER BY bus_time ASC ";
                }
                // echo $sql;
            }

            if (!$conn)
            {
                die("Connection failed: " . mysqli_connect_error());
            }
            $result = mysqli_query($conn, $sql);
            //$first_bus = mysqli_fetch_assoc($result)['bus_time'];
			date_default_timezone_set("America/New_York");
             while($row = mysqli_fetch_assoc($result))
             {
				 $now = new DateTime();
				 $bus_time = new DateTime($row['bus_time']);
				 //print_r($now);
				 //print_r($row) ;
                   //  echo "<br>";
				 if($now <= $bus_time)
				 {
					 $first_bus = $row['bus_time'];
					// echo $first_bus;
					 break 1;
				 }
				 

             }
			 
			 //$ticket_string = "barcode.php?htmlBarcode";
			
    ?>
    <body>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
       <script type="text/javascript" src="js/materialize.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <!--  ===========================  Navigation =========================== -->
      <nav>
         <div class="nav-wrapper teal">
         <a href="https://www.lambtoncollege.ca/toronto/" class="brand-logo">
             Lambton College Toronto
         </a>
         <ul class="right hide-on-med-and-down">
           <li><a onclick="show_all_bus_route()"><i class="material-icons">view_module</i></a></li>
           <li><a href="dashboard.php"><i class="material-icons">home</i></a></li>
         </ul>
       </div>
     </nav>
     <!--  ===========================   Page Content =========================== -->
     <div class="container">
         <div class="row">
             <div class="col l12 center" style="padding-top:40px;">
                 <lable  style="font-size:30px; color:black;">
                     <?php echo $next_lbl ?>  <!-- TODO dynamic labels -->
                 </label>
                 <lable id="counter"  style="font-size:30px; color:red;">
                     0:34:56
                 </label>
             </div>
         </div> <!-- row -->
         <div class="row">
             <div class="col l12 center" >
                 <a  style="font-size:20px; color:black;
                        text-decoration:underline"
                        onclick="show_all_bus_route()">
                    Show other schedule buses.
                 </a>
             </div>
         </div> <!-- row -->
         <div class="col l12 center" style="padding-top:-10px;"  id="image_div">
             <image src="map.png" width="100%" height="350px" />
         </div> <!-- row -->
         <div class="row" id="bus_schedule_div" style="display:none;">
             <div class="cal l12 center">
				
               <table>

                 <?php
				
                 while($row = mysqli_fetch_assoc($result))
                 {  ?>
						<tr>
							<td><?php echo " Labton College";?></td>
							<td><?php echo $location; ?></td>
							<td><?php echo $row['bus_time']; ?></td>
							<td><a id="buy_ticket" href="popup.php? <?php $row['bus_time']; ?>" 
							>
                                <i class="fa fa-ticket fa-2x " aria-hidden="true"></i>
                             </a>
							</td>
						</tr>
				<?php
			     } 
				  
				 ?>
			    </table>
             </div>
         </div> <!-- row -->
     </div> <!-- CONTAINER -->
 <!--  ===========================   model  =========================== -->
 
 <!--  ===========================   Script =========================== -->
 
 
     <script>

		
		
		
     var cur_hour =  new Date().getHours();
     var cur_minutes =  new Date().getMinutes();
     var cur_timestemp = cur_hour +  ":" + cur_minutes  ;
     //console.log("Curret Time :  " + cur_timestemp ) ;
     //var bus_time = "20:48" ;  // take time from database
     var seconds = 23;
     var startTime=moment(cur_timestemp, "HH:mm:ss");
     //var endTime=moment(bus_time, "HH:mm");
     var bus_time_from_php = "<?php echo $first_bus ?>";
     var endTime=moment(bus_time_from_php , "HH:mm:ss");

     var duration = moment.duration(endTime.diff(startTime));
     var hours = parseInt(duration.asHours());
     var minutes = parseInt(duration.asMinutes())-hours*60;
     //console.log("Time  Difrence   :  " + hours + " ---- " + minutes + "-----"  + seconds) ;


     my_var =  window.setInterval(cout_down, 400); // TODO change it to 1000 //TODO uncomment to run timer
     function cout_down()
     {
         seconds = seconds - 1 ;
         if(seconds <= 0 && (hours != 0 || minutes != 0))
         {
             seconds = 59;
             minutes = minutes - 1;
         }
         if(minutes <= 0 && hours != 0)
         {
             if(hours >=1)
             {
                 minutes = 59;
                 hours = hours - 1;
             }
         }
         if(hours <= 0 && minutes <= 0 && seconds <= 0)
         {
              window.clearInterval(my_var); // to stop timer :
         }
         var time_left = hours + " : " + minutes + " : " +  seconds;
         //console.log(" --------------  " + hours + " : " + minutes + " : " +  seconds);
		 //onclick="prompt('Enter Your Name and Student Number like : C0xxxxxYOURNAME')"
         $(counter).text(time_left);
     }
     //counter

     function show_all_bus_route()
     {
         var x = document.getElementById("image_div");//id="bus_schedule_div"
         var y = document.getElementById("bus_schedule_div");//id="bus_schedule_div"
        if (x.style.display === "none")
        {
            x.style.display = "block";
            y.style.display = "none";
        } else {
            x.style.display = "none";
            y.style.display = "block";
        }
		
    }// function

	
	function show_barcode()
	{
		console.log("-----------------");
		var x1 = document.getElementById("bar");//id="bar"
		x1.style.display = "block";
	}
    </script>

<?php
    mysqli_close($conn);
 ?>

   </body>
</html>
