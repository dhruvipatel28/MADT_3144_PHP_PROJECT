<!--

1->  Set logo on top -> onclick open lambton website
2->  Deshboard on right top corner icon click -> show full schedule. (Give it a formate)
3->

-->


<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>


      <?php
          $servername = "localhost";
          $username = "root";
          $password = "";
          $dbname = "my_db";
          // Create connection
          $conn = mysqli_connect($servername, $username, $password, $dbname);
          // Check connection
          if (!$conn)
          {
              die("Connection failed: " . mysqli_connect_error());
          }
          else
          {
                $sql = "select * from bus_schedule ORDER BY bus_time ASC ";
                $result = mysqli_query($conn, $sql);
          }
          // Get the full schedule.
      ?>

    </head>
    <body>  
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
      <!--   <script type="text/javascript" src="js/materialize.min.js"></script> -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <!-- slider css
      <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> -->
      <!--  ===========================  Navigation =========================== -->
      <nav>
         <div class="nav-wrapper teal">
         <a href="https://www.lambtoncollege.ca/toronto/" class="brand-logo">
             Lambton College Toronto
         </a>
         <ul class="right hide-on-med-and-down">
           <li><a onclick="show_bus_schedule()"><i class="material-icons">view_module</i></a></li>
         </ul>
       </div>
     </nav>
     <!--  ===========================   Page Content =========================== -->
     <div class="container" >
         <div class="row" id="selection_div">
             <div class="col s12  nav-wrapper" style="padding-top:40px">
                  <div class="card blue-grey darken-1">
                        <div class="card-content white-text">
                          <span class="card-title"> Missisauga / Brampton</span> <!--  Dynamic list-->
                          <p> Select The Location You Want to go.</p>
                        </div>
                        <div class="card-action">
                            <!--  Dynamic list-->
                            <a  href="result.php?des=to&loc=mississauga" class="btn waves-effect waves-light btn-large waves-red"
                                    style="background-color:#cccccc; color:black;"
                                     >Mississauga</a>
                            <a href="result.php?des=to&loc=brampton" class="btn waves-effect waves-light btn-large waves-yellow"
                                    style="background-color:#cccccc; color:black;
                                            margin-left:40px;"
                                     >Brampton</a>
                        </div>
                  </div>
              </div>
         </div> <!-- row -->
         <div class="row" id="selection_div2">
             <div class="col s12  nav-wrapper">
                  <div class="card blue-grey darken-1">
                        <div class="card-content white-text">
                          <span class="card-title">Lambton College Toronto</span> <!--  Dynamic list-->
                          <p> Select Your Location From Where You Want To Go College.</p>
                        </div>
                        <div class="card-action">
                            <!--  Dynamic list-->
                            <a href="result.php?des=from&loc=mississauga" class="btn waves-effect waves-light btn-large waves-red "
                                    style="background-color:#cccccc; color:black;"
                                     >Mississauga</a>
                            <a href="result.php?des=from&loc=brampton" class="btn waves-effect waves-light btn-large waves-yellow "
                                    style="background-color:#cccccc; color:black; margin-left:40px;"
                                     >Brampton</a>
                        </div>
                  </div>
              </div>
         </div> <!-- row -->
     </div> <!-- CONTAINER -->
     <div class="container">
         <div class="row"   id="bus_schedule_div" style="display:none; padding-top:80px ;">
             <div class="cal l12 center">
                 <table style="border: solid black 1px;">
                     <tr>
                        <td> Bus number</td>
                        <td> Pick up Locaion </td>
                        <td> Destination </td>
                        <td> Detature time </td>
                        <td> On saturday </td>
                    </tr>
                     <tr>
                         <td> bus 1</td>
                         <td> Miss / Bra </td>
                         <td> Labton College </td>
                         <td> 11:45 </td>
                         <td>yes / No </td>
                     </tr>
                 </table>
                 <?php
                 while($row = mysqli_fetch_assoc($result))
                 {
                     print_r($row) ;
                     echo "<br>";
                 }
                  ?>
             </div>
         </div> <!-- row -->
     </div><!-- Container -->
 <!--  ===========================   Script =========================== -->
     <script>

     function show_bus_schedule()
     {
         var x = document.getElementById("bus_schedule_div");//id="bus_schedule_div"
         var y = document.getElementById("selection_div");//id="bus_schedule_div"
         var z = document.getElementById("selection_div2");//id="bus_schedule_div"
        if (x.style.display === "none")
        {
            x.style.display = "block";
            y.style.display = "none";
            z.style.display = "none";
        } else {
            x.style.display = "none";
            y.style.display = "block";
            z.style.display = "block";
        }
     }

    </script>
    <?php
        mysqli_close($conn);
     ?>


   </body>
</html>
